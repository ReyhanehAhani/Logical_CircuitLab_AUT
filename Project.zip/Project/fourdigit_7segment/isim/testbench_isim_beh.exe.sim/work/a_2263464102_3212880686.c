/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "F:/term5/madar-mantegi-az/Project/fourdigit_7segment/bcd_to_segment.vhd";



static void work_a_2263464102_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(21, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = *((int *)t2);
    if (t3 == 0)
        goto LAB3;

LAB13:    if (t3 == 1)
        goto LAB4;

LAB14:    if (t3 == 2)
        goto LAB5;

LAB15:    if (t3 == 3)
        goto LAB6;

LAB16:    if (t3 == 4)
        goto LAB7;

LAB17:    if (t3 == 5)
        goto LAB8;

LAB18:    if (t3 == 6)
        goto LAB9;

LAB19:    if (t3 == 7)
        goto LAB10;

LAB20:    if (t3 == 8)
        goto LAB11;

LAB21:
LAB12:    xsi_set_current_line(31, ng0);
    t1 = (t0 + 4838);
    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 7U);

LAB2:    xsi_set_current_line(34, ng0);
    t1 = (t0 + 1488U);
    t2 = *((char **)t1);
    t1 = (t0 + 2872);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t2, 7U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 2792);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(22, ng0);
    t1 = (t0 + 4775);
    t5 = (t0 + 1488U);
    t6 = *((char **)t5);
    t5 = (t6 + 0);
    memcpy(t5, t1, 7U);
    goto LAB2;

LAB4:    xsi_set_current_line(23, ng0);
    t1 = (t0 + 4782);
    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 7U);
    goto LAB2;

LAB5:    xsi_set_current_line(24, ng0);
    t1 = (t0 + 4789);
    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 7U);
    goto LAB2;

LAB6:    xsi_set_current_line(25, ng0);
    t1 = (t0 + 4796);
    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 7U);
    goto LAB2;

LAB7:    xsi_set_current_line(26, ng0);
    t1 = (t0 + 4803);
    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 7U);
    goto LAB2;

LAB8:    xsi_set_current_line(27, ng0);
    t1 = (t0 + 4810);
    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 7U);
    goto LAB2;

LAB9:    xsi_set_current_line(28, ng0);
    t1 = (t0 + 4817);
    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 7U);
    goto LAB2;

LAB10:    xsi_set_current_line(29, ng0);
    t1 = (t0 + 4824);
    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 7U);
    goto LAB2;

LAB11:    xsi_set_current_line(30, ng0);
    t1 = (t0 + 4831);
    t4 = (t0 + 1488U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 7U);
    goto LAB2;

LAB22:;
}


extern void work_a_2263464102_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2263464102_3212880686_p_0};
	xsi_register_didat("work_a_2263464102_3212880686", "isim/testbench_isim_beh.exe.sim/work/a_2263464102_3212880686.didat");
	xsi_register_executes(pe);
}
